import { defineConfig } from 'astro/config';
import { fontProviders } from 'astro/config';

export default defineConfig({
  site: 'https://heleme69.github.io',
  base: '/MyBlog',
  experimental: {
    fonts: [{
      provider: fontProviders.google(),
      name: 'Atkinson Hyperlegible',
      cssVariable: '--font-atkinson',
    }]
  }
});